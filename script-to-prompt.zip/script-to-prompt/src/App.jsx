import { useState, useRef } from "react";

const SYSTEM_PROMPT = `You are an expert cinematic prompt engineer. Convert each sentence/line from a documentary script into THREE prompts.

STRICT CHARACTER RULES (apply to ALL prompts):
- All characters = human white dummy figures with scene-appropriate clothing
- NO facial features: no eyes, no nose, no mouth, no ears, no hair — faces completely smooth and featureless
- Style: Cinematic, ultra-realistic, high-end 3D rendered quality
- Lighting: dramatic, realistic, film-like

OUTPUT: Return a JSON array. Each element must have exactly these fields:
{
  "line": "original script line",
  "camera": "one camera movement from: Dolly In / Dolly Out / Slow Zoom In / Slow Zoom Out / Pan Left / Pan Right / Tilt Up / Tilt Down / Orbit Shot / Tracking Shot / Static with Environmental Motion / Crane Up / Crane Down / Push In with Slight Handheld Shake",
  "image_prompt": "Ultra-realistic cinematic 3D rendered scene featuring [white dummy figure characters + environment + action + mood + lighting + setting — NO facial features]",
  "video_prompt": "Cinematic [camera movement] shot — [scene description with motion, atmosphere, timing] — [character action/movement] — [lighting mood] — [duration hint e.g. 4-second slow push] — ultra-realistic 3D rendered, film-grade quality, no facial features on characters"
}

VIDEO PROMPT RULES:
- Must describe MOTION (what moves, how, speed)
- Include camera movement name at start
- Describe atmosphere (fog, dust, light rays, etc.)
- Describe character body language / action (no face)
- Suitable for Kling / Runway / Higgsfield AI video generation
- 2-3 sentences max, dense and visual

Return ONLY valid JSON array. No explanation. No markdown backticks.`;

const TABS = ["IMAGE", "VIDEO"];

export default function App() {
  const [script, setScript] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(null);
  const [activeTab, setActiveTab] = useState({});
  const outputRef = useRef(null);

  async function generate() {
    if (!script.trim()) return;
    setLoading(true);
    setError("");
    setResults([]);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": import.meta.env.VITE_ANTHROPIC_KEY,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: `Convert this documentary script:\n\n${script}` }]
        })
      });

      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResults(parsed);
      const tabs = {};
      parsed.forEach((_, i) => { tabs[i] = "IMAGE"; });
      setActiveTab(tabs);
      setTimeout(() => outputRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    } catch (e) {
      setError("সমস্যা হয়েছে। API Key ঠিক আছে কিনা চেক করুন।");
    } finally {
      setLoading(false);
    }
  }

  function copyPrompt(idx, type) {
    const r = results[idx];
    const text = type === "IMAGE" ? r.image_prompt : r.video_prompt;
    navigator.clipboard.writeText(text);
    setCopied(`${idx}-${type}`);
    setTimeout(() => setCopied(null), 2000);
  }

  function copyAll(type) {
    const text = results.map((r, i) =>
      `[Scene ${i + 1}]\nOriginal: ${r.line}\nCamera: ${r.camera}\n${type} Prompt: ${type === "IMAGE" ? r.image_prompt : r.video_prompt}`
    ).join("\n\n---\n\n");
    navigator.clipboard.writeText(text);
    setCopied(`all-${type}`);
    setTimeout(() => setCopied(null), 2000);
  }

  const setTab = (idx, tab) => setActiveTab(prev => ({ ...prev, [idx]: tab }));

  return (
    <div style={{ minHeight: "100vh", background: "#07070f", color: "#e8e0d0", fontFamily: "'Courier New', monospace" }}>
      <div style={{ borderBottom: "1px solid #1e1830", padding: "20px 28px", background: "linear-gradient(135deg, #0d0a18 0%, #0a0e1a 100%)", display: "flex", alignItems: "center", gap: "14px" }}>
        <div style={{ width: "38px", height: "38px", background: "linear-gradient(135deg, #c8a96e, #7a4e2c)", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px", flexShrink: 0 }}>🎬</div>
        <div>
          <div style={{ fontSize: "16px", fontWeight: "bold", letterSpacing: "3px", color: "#c8a96e" }}>SCRIPT → IMAGE + VIDEO PROMPT</div>
          <div style={{ fontSize: "10px", color: "#5a5068", letterSpacing: "2px", marginTop: "2px" }}>CINEMATIC DOCUMENTARY CONVERTER · KLING / RUNWAY / MIDJOURNEY</div>
        </div>
      </div>

      <div style={{ padding: "28px", maxWidth: "920px", margin: "0 auto" }}>
        <div style={{ marginBottom: "8px", display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontSize: "10px", letterSpacing: "2px", color: "#7a6a5a" }}>▸ SCRIPT INPUT</span>
          <span style={{ fontSize: "10px", color: "#3a3040" }}>{script.length} chars</span>
        </div>

        <textarea
          value={script}
          onChange={e => setScript(e.target.value)}
          placeholder={"Documentary script paste করুন...\n\nAt 3:47 AM, everything changed.\nThe servers began to fail one by one.\nBy the time engineers realized what was happening, it was already too late."}
          style={{ width: "100%", minHeight: "200px", background: "#0c0918", border: "1px solid #201a30", borderRadius: "8px", color: "#d4c8b8", fontFamily: "'Courier New', monospace", fontSize: "13px", lineHeight: "1.9", padding: "18px", resize: "vertical", outline: "none", boxSizing: "border-box", caretColor: "#c8a96e" }}
          onFocus={e => e.target.style.borderColor = "#c8a96e"}
          onBlur={e => e.target.style.borderColor = "#201a30"}
        />

        <button
          onClick={generate}
          disabled={loading || !script.trim()}
          style={{ marginTop: "14px", width: "100%", padding: "15px", background: loading ? "#13101e" : "linear-gradient(135deg, #c8a96e 0%, #7a4e2c 100%)", border: "none", borderRadius: "8px", color: loading ? "#5a5068" : "#07070f", fontSize: "12px", fontWeight: "bold", letterSpacing: "4px", cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Courier New', monospace", transition: "all 0.3s" }}
        >
          {loading ? "⏳  GENERATING..." : "▶  GENERATE IMAGE + VIDEO PROMPTS"}
        </button>

        {error && <div style={{ marginTop: "10px", padding: "12px 16px", background: "#180a0a", border: "1px solid #3a1a1a", borderRadius: "6px", color: "#c07070", fontSize: "12px" }}>{error}</div>}

        {results.length > 0 && (
          <div ref={outputRef} style={{ marginTop: "36px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "18px", flexWrap: "wrap", gap: "8px" }}>
              <span style={{ fontSize: "10px", letterSpacing: "2px", color: "#7a6a5a" }}>▸ {results.length} SCENES GENERATED</span>
              <div style={{ display: "flex", gap: "8px" }}>
                {["IMAGE", "VIDEO"].map(type => (
                  <button key={type} onClick={() => copyAll(type)} style={{ padding: "7px 14px", background: copied === `all-${type}` ? "#0e1e0e" : "#100e18", border: `1px solid ${copied === `all-${type}` ? "#3a7a3a" : "#201a30"}`, borderRadius: "5px", color: copied === `all-${type}` ? "#5ab85a" : "#7a6a8a", fontSize: "10px", letterSpacing: "1px", cursor: "pointer", fontFamily: "'Courier New', monospace" }}>
                    {copied === `all-${type}` ? `✓ ${type} COPIED` : `⊡ ALL ${type}`}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {results.map((r, i) => {
                const tab = activeTab[i] || "IMAGE";
                const isImg = tab === "IMAGE";
                const prompt = isImg ? r.image_prompt : r.video_prompt;
                const copyKey = `${i}-${tab}`;
                return (
                  <div key={i} style={{ background: "#0b0916", border: "1px solid #1a1626", borderRadius: "10px", overflow: "hidden" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 14px", background: "#0e0c1a", borderBottom: "1px solid #1a1626" }}>
                      <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                        <span style={{ fontSize: "9px", letterSpacing: "2px", color: "#c8a96e", background: "#1c1408", padding: "2px 8px", borderRadius: "4px" }}>SCENE {i + 1}</span>
                        <span style={{ fontSize: "9px", color: "#5a4a6a", background: "#100e18", padding: "2px 8px", borderRadius: "4px" }}>📷 {r.camera}</span>
                      </div>
                      <button onClick={() => copyPrompt(i, tab)} style={{ padding: "3px 10px", background: copied === copyKey ? "#0e1e0e" : "transparent", border: `1px solid ${copied === copyKey ? "#3a7a3a" : "#201a30"}`, borderRadius: "4px", color: copied === copyKey ? "#5ab85a" : "#5a5068", fontSize: "9px", cursor: "pointer", fontFamily: "'Courier New', monospace", letterSpacing: "1px" }}>
                        {copied === copyKey ? "✓ COPIED" : "⊡ COPY"}
                      </button>
                    </div>

                    <div style={{ padding: "14px" }}>
                      <div style={{ fontSize: "12px", color: "#8a7a6a", lineHeight: "1.7", fontStyle: "italic", marginBottom: "12px", paddingLeft: "10px", borderLeft: "2px solid #201a30" }}>{r.line}</div>
                      <div style={{ display: "flex", gap: "0", marginBottom: "10px", borderRadius: "6px", overflow: "hidden", border: "1px solid #201a30", width: "fit-content" }}>
                        {TABS.map(t => (
                          <button key={t} onClick={() => setTab(i, t)} style={{ padding: "6px 18px", background: tab === t ? (t === "IMAGE" ? "linear-gradient(135deg, #c8a96e, #7a4e2c)" : "linear-gradient(135deg, #6e8ec8, #2c4e8b)") : "#0e0c1a", border: "none", color: tab === t ? "#07070f" : "#5a5068", fontSize: "10px", fontWeight: "bold", letterSpacing: "2px", cursor: "pointer", fontFamily: "'Courier New', monospace", transition: "all 0.2s" }}>
                            {t === "IMAGE" ? "🖼 IMAGE" : "🎥 VIDEO"}
                          </button>
                        ))}
                      </div>
                      <div style={{ fontSize: "12px", color: "#d4c8b8", lineHeight: "1.8", background: isImg ? "#080614" : "#060810", padding: "13px", borderRadius: "6px", border: `1px solid ${isImg ? "#16121f" : "#0e1220"}`, userSelect: "all", minHeight: "60px" }}>{prompt}</div>
                      <div style={{ marginTop: "6px", fontSize: "9px", color: "#3a3040", letterSpacing: "1px" }}>{isImg ? "→ Midjourney · Leonardo · DALL-E · Stable Diffusion" : "→ Kling · Runway · Higgsfield · Pika · Sora"}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
